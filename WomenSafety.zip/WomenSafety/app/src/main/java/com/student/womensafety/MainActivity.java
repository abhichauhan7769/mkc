package com.student.womensafety;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button to navigate to MapsActivity
        findViewById(R.id.btn_open_map).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, MapsActivity.class));
        });

        // SOS button to send alert
        findViewById(R.id.btn_sos).setOnClickListener(v -> sendSOS());
    }

    private void sendSOS() {
        String emergencyMessage = "I am in danger! Here's my location: <location>";
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, emergencyMessage);
        sendIntent.setType("text/plain");
        if (sendIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(sendIntent);
        }
    }
}